const fs = require('fs');
const path = require('path');

class Metrics {
  constructor(options = {}) {
    this.file = options.file || path.join(__dirname, 'metrics-store.jsonl');
    this.events = []; // in-memory recent events {ts, feature, type, state?}
    this.maxEvents = options.maxEvents || 20000;
    this._loadRecent();
  }

  _appendToFile(ev) {
    try {
      fs.appendFileSync(this.file, JSON.stringify(ev) + '\n');
    } catch (e) {
      // best-effort
      console.error('metrics write failed', e && e.message);
    }
  }

  _loadRecent() {
    try {
      if (!fs.existsSync(this.file)) return;
      // read last ~maxEvents lines (naive: read whole file if small)
      const raw = fs.readFileSync(this.file, 'utf8').trim();
      if (!raw) return;
      const lines = raw.split('\n');
      const start = Math.max(0, lines.length - this.maxEvents);
      for (let i = start; i < lines.length; i++) {
        try { this.events.push(JSON.parse(lines[i])); } catch (e) {}
      }
    } catch (e) {
      // ignore
    }
  }

  _push(event) {
    this.events.push(event);
    if (this.events.length > this.maxEvents) this.events.splice(0, this.events.length - this.maxEvents);
    this._appendToFile(event);
  }

  countExposure(feature, kind) {
    const ev = { ts: Date.now(), feature, type: 'exposure', state: kind }; // kind: 'on'|'off'
    this._push(ev);
  }

  countActivation(feature) {
    const ev = { ts: Date.now(), feature, type: 'activation' };
    this._push(ev);
  }

  countError(feature) {
    const ev = { ts: Date.now(), feature, type: 'error' };
    this._push(ev);
  }

  // aggregate all-time snapshot (fast approximate from in-memory)
  snapshot() {
    const out = {};
    this.events.forEach(ev => {
      out[ev.feature] = out[ev.feature] || { exposures: { on: 0, off: 0 }, activations: 0, errors: 0 };
      if (ev.type === 'exposure') {
        if (ev.state === 'on') out[ev.feature].exposures.on++;
        else out[ev.feature].exposures.off++;
      } else if (ev.type === 'activation') out[ev.feature].activations++;
      else if (ev.type === 'error') out[ev.feature].errors++;
    });
    return out;
  }

  // compute aggregated stats for the last windowMs milliseconds
  windowStats(windowMs = 5 * 60 * 1000) {
    const cutoff = Date.now() - windowMs;
    const out = {};
    for (let i = this.events.length - 1; i >= 0; i--) {
      const ev = this.events[i];
      if (ev.ts < cutoff) break;
      out[ev.feature] = out[ev.feature] || { exposures: { on: 0, off: 0 }, activations: 0, errors: 0 };
      if (ev.type === 'exposure') {
        if (ev.state === 'on') out[ev.feature].exposures.on++;
        else out[ev.feature].exposures.off++;
      } else if (ev.type === 'activation') out[ev.feature].activations++;
      else if (ev.type === 'error') out[ev.feature].errors++;
    }
    return out;
  }
}

module.exports = Metrics;
