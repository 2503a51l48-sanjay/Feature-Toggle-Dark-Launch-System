const fs = require('fs');
const path = require('path');

class AuditLog {
  constructor(file) {
    this.file = file || path.join(__dirname, 'audit-log.json');
    try {
      if (!fs.existsSync(this.file)) fs.writeFileSync(this.file, JSON.stringify([]));
    } catch (e) {
      console.error('failed to init audit file', e);
    }
  }

  _read() {
    try {
      const raw = fs.readFileSync(this.file, 'utf8');
      return JSON.parse(raw || '[]');
    } catch (e) {
      return [];
    }
  }

  _write(list) {
    try {
      fs.writeFileSync(this.file, JSON.stringify(list, null, 2));
    } catch (e) {
      console.error('failed to write audit', e);
    }
  }

  add(entry) {
    const list = this._read();
    entry.timestamp = Date.now();
    list.unshift(entry);
    // keep last 1000
    if (list.length > 1000) list.length = 1000;
    this._write(list);
  }

  list(limit = 200) {
    const list = this._read();
    return list.slice(0, limit);
  }
}

module.exports = AuditLog;
