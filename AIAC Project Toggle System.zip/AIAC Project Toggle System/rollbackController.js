class RollbackController {
  constructor(toggleService, metrics, options = {}) {
    this.toggleService = toggleService;
    this.metrics = metrics;
    this.checkInterval = options.checkInterval || 5000; // ms
    this.errorRateThreshold = options.errorRateThreshold || 0.2; // 20% errors
    this.minExposures = options.minExposures || 10;
    this.windowMs = options.windowMs || 60 * 1000; // sliding window for error rate
    this._start();
  }

  _start() {
    this.timer = setInterval(() => this._evaluate(), this.checkInterval);
  }

  _evaluate() {
    // use sliding-window stats
    const snap = this.metrics.windowStats(this.windowMs);
    Object.keys(snap).forEach(feature => {
      const data = snap[feature];
      const exposures = (data.exposures.on || 0) + (data.exposures.off || 0);
      if (exposures < this.minExposures) return; // not enough data
      const errors = data.errors || 0;
      const errorRate = exposures > 0 ? errors / exposures : 0;
      if (errorRate >= this.errorRateThreshold) {
        const t = this.toggleService.get(feature);
        if (t && t.rollout > 0) {
          console.log(`Rolling back feature=${feature} due to window errorRate=${errorRate.toFixed(2)} exposures=${exposures}`);
          this.toggleService.setRollout(feature, 0);
        }
      }
    });
  }
}

module.exports = RollbackController;
