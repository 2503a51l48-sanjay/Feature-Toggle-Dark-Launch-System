# AIAC Toggle System - Database Setup Guide

## Quick Start

### Option 1: Using File-Based Storage (Default)
The system works out of the box with file-based JSON storage:
```bash
npm start
```

### Option 2: Using MongoDB (Recommended for Production)

#### Prerequisites
- MongoDB installed and running locally
- Or use MongoDB Atlas (cloud version)

#### Installation Steps

1. **Start MongoDB locally** (if installed):
```bash
# macOS with Homebrew
brew services start mongodb-community

# Or run as a service:
mongod
```

2. **Configure MongoDB connection** in `.env`:
```bash
# For local MongoDB (default)
MONGODB_URI=mongodb://localhost:27017/aiac_toggle_system

# For MongoDB Atlas (cloud)
MONGODB_URI=mongodb+srv://username:password@cluster0.mongodb.net/aiac_toggle_system?retryWrites=true&w=majority
```

3. **Start the server**:
```bash
npm start
```

The server will automatically:
- ✅ Try to connect to MongoDB
- ✅ Create database collections if they don't exist
- ✅ Fall back to file-based storage if MongoDB is unavailable

## API Endpoints

### Health & Status
- `GET /api/health` - Server health check
- `GET /api/status` - Database status and configuration

### Feature Toggles
- `GET /api/toggles` - List all toggles
- `POST /api/toggles` - Create/update toggle (requires admin token)
- `GET /api/toggles/:name` - Get specific toggle
- `POST /api/toggles/:name/rollback` - Rollback toggle (requires admin token)

### Metrics
- `GET /api/metrics` - Current metrics snapshot
- `GET /api/metrics/window?ms=60000` - Windowed metrics (last N milliseconds)
- `POST /api/metrics/activation` - Record activation
- `POST /api/metrics/error` - Record error
- `GET /api/metrics/prometheus` - Prometheus-format metrics

### Evaluation & Audit
- `GET /api/evaluate/:feature` - Evaluate feature for user
- `GET /api/audit` - Get audit log entries

## Environment Variables

```env
# Database
MONGODB_URI=mongodb://localhost:27017/aiac_toggle_system

# Server
PORT=3333
ADMIN_TOKEN=dev-secret
NODE_ENV=development

# Thresholds
ERROR_RATE_THRESHOLD=0.25
MIN_EXPOSURES=8
ROLLBACK_CHECK_INTERVAL=5000
METRICS_WINDOW_MS=60000
```

## Monitoring

### Check Server Status
```bash
curl http://localhost:3333/api/health
curl http://localhost:3333/api/status
```

### View Metrics
```bash
curl http://localhost:3333/api/metrics/window?ms=60000
curl http://localhost:3333/api/metrics/prometheus
```

## Database Schema (MongoDB)

### Collections

**toggles**
- name (unique)
- enabled
- rollout (0-100)
- constraints (optional)
- updatedAt
- createdAt

**metrics**
- feature
- timestamp
- exposures { on, off }
- activations
- errors

**audit_logs**
- type (toggle_update, rollback, etc.)
- feature
- by (user/system)
- detail
- timestamp

## Troubleshooting

### MongoDB Connection Failed
- Ensure MongoDB is running: `mongod` or `brew services start mongodb-community`
- Check `MONGODB_URI` in `.env`
- Server will fallback to file-based storage automatically

### Reset Data
```bash
# File-based storage
rm toggle-store.json metrics-buckets.jsonl audit-log.json

# MongoDB
# Connect to MongoDB and drop the database:
# use aiac_toggle_system
# db.dropDatabase()
```

## Production Deployment

For production:
1. Use MongoDB Atlas (managed cloud database)
2. Set custom `ADMIN_TOKEN` (strong password)
3. Use environment-specific `.env` files
4. Enable HTTPS
5. Set `NODE_ENV=production`

Example `.env` for production:
```env
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/aiac_toggle_system
ADMIN_TOKEN=your-secure-token-here
PORT=3333
NODE_ENV=production
```
