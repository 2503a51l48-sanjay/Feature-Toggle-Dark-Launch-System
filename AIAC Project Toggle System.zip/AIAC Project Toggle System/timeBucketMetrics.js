const fs = require('fs');
const path = require('path');

/**
 * Time-bucket aggregation for accurate sliding-window stats.
 * Buckets: fixed 10-second intervals. Each bucket tracks counts per feature.
 * Sliding window: sum over buckets within the requested window.
 */
class TimeBucketMetrics {
  constructor(options = {}) {
    this.bucketSizeMs = options.bucketSizeMs || 10 * 1000; // 10s buckets
    this.file = options.file || path.join(__dirname, 'metrics-buckets.jsonl');
    this.maxBuckets = options.maxBuckets || 1000; // ~2.7 hours of 10s buckets
    this.buckets = {}; // { bucketId: { feature: { on: N, off: M, errors: K, activations: L } } }
    this._loadBuckets();
  }

  _getBucketId(ts) {
    return Math.floor(ts / this.bucketSizeMs);
  }

  _loadBuckets() {
    try {
      if (!fs.existsSync(this.file)) return;
      const lines = fs.readFileSync(this.file, 'utf8').trim().split('\n').filter(l => l);
      for (const line of lines) {
        try {
          const entry = JSON.parse(line);
          this.buckets[entry.bucketId] = entry.data;
        } catch (e) {}
      }
    } catch (e) {
      console.error('Failed to load metrics buckets', e && e.message);
    }
  }

  _persistBucket(bucketId) {
    try {
      fs.appendFileSync(this.file, JSON.stringify({ bucketId, data: this.buckets[bucketId] }) + '\n');
    } catch (e) {
      console.error('Failed to persist bucket', e && e.message);
    }
  }

  _ensureBucket(bucketId) {
    if (!this.buckets[bucketId]) {
      this.buckets[bucketId] = {};
      this._persistBucket(bucketId);
    }
  }

  _ensureFeatureInBucket(bucketId, feature) {
    if (!this.buckets[bucketId][feature]) {
      this.buckets[bucketId][feature] = { on: 0, off: 0, errors: 0, activations: 0 };
    }
  }

  // record event: exposure (on/off), activation, or error
  countExposure(feature, kind) {
    const bucketId = this._getBucketId(Date.now());
    this._ensureBucket(bucketId);
    this._ensureFeatureInBucket(bucketId, feature);
    if (kind === 'on') this.buckets[bucketId][feature].on++;
    else this.buckets[bucketId][feature].off++;
  }

  countActivation(feature) {
    const bucketId = this._getBucketId(Date.now());
    this._ensureBucket(bucketId);
    this._ensureFeatureInBucket(bucketId, feature);
    this.buckets[bucketId][feature].activations++;
  }

  countError(feature) {
    const bucketId = this._getBucketId(Date.now());
    this._ensureBucket(bucketId);
    this._ensureFeatureInBucket(bucketId, feature);
    this.buckets[bucketId][feature].errors++;
  }

  // compute all-time stats
  snapshot() {
    const out = {};
    Object.keys(this.buckets).forEach(bucketId => {
      const bucket = this.buckets[bucketId];
      Object.keys(bucket).forEach(feature => {
        out[feature] = out[feature] || { exposures: { on: 0, off: 0 }, activations: 0, errors: 0 };
        const counts = bucket[feature];
        out[feature].exposures.on += counts.on || 0;
        out[feature].exposures.off += counts.off || 0;
        out[feature].activations += counts.activations || 0;
        out[feature].errors += counts.errors || 0;
      });
    });
    return out;
  }

  // compute windowed stats (recent data within windowMs)
  windowStats(windowMs = 5 * 60 * 1000) {
    const now = Date.now();
    const cutoffBucketId = this._getBucketId(now - windowMs);
    const currentBucketId = this._getBucketId(now);
    const out = {};
    for (let bid = cutoffBucketId; bid <= currentBucketId; bid++) {
      if (!this.buckets[bid]) continue;
      const bucket = this.buckets[bid];
      Object.keys(bucket).forEach(feature => {
        out[feature] = out[feature] || { exposures: { on: 0, off: 0 }, activations: 0, errors: 0 };
        const counts = bucket[feature];
        out[feature].exposures.on += counts.on || 0;
        out[feature].exposures.off += counts.off || 0;
        out[feature].activations += counts.activations || 0;
        out[feature].errors += counts.errors || 0;
      });
    }
    return out;
  }

  // cleanup old buckets
  cleanup() {
    const now = Date.now();
    const maxAgeBucketId = this._getBucketId(now - (this.maxBuckets * this.bucketSizeMs));
    const ids = Object.keys(this.buckets).map(Number).sort((a, b) => a - b);
    for (const bid of ids) {
      if (bid < maxAgeBucketId) delete this.buckets[bid];
    }
  }
}

module.exports = TimeBucketMetrics;
