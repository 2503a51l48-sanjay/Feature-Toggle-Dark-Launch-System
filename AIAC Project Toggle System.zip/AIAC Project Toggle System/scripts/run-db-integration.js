require('dotenv').config();
const Database = require('../db');

(async function(){
  const db = new Database(process.env.MONGODB_URI);
  const ok = await db.connect();
  if (!ok) {
    console.error('DB connect failed');
    process.exit(2);
  }
  const clientDb = db.getDatabase();
  const col = clientDb.collection('toggles');
  const name = 'script-test-toggle';
  try {
    await col.deleteOne({ name });
    const doc = { name, enabled: true, rollout: 33, constraints: {}, createdAt: new Date(), updatedAt: new Date() };
    const r = await col.insertOne(doc);
    if (!r.insertedId) throw new Error('insert failed');
    const got = await col.findOne({ name });
    if (!got) throw new Error('read after insert failed');
    if (got.rollout !== 33) throw new Error('value mismatch');
    console.log('✅ DB integration script test passed');
    // duplicate insert attempt
    let dupOk = false;
    try {
      await col.insertOne(doc);
    } catch (e) {
      dupOk = true; // expected error
    }
    if (!dupOk) console.warn('⚠ duplicate insert did not error (index may be missing)');
    await col.deleteOne({ name });
    await db.disconnect();
    process.exit(0);
  } catch (e) {
    console.error('DB integration test failed:', e.message);
    try { await col.deleteOne({ name }); } catch (e) {}
    await db.disconnect();
    process.exit(1);
  }
})();
