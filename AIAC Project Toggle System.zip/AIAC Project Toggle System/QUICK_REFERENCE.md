# 🚀 AIAC Toggle System — Quick Reference Card

## **Start Server**
```bash
npm start
# Opens: http://localhost:3333
```

## **Default Admin Token**
```
dev-secret
```

## **Create Toggle (Dashboard)**
1. Open http://localhost:3333
2. Feature Toggles tab → Create New Toggle form
3. Fill: Name, Rollout %, Countries (optional)
4. Click "Create Toggle"

## **Create Toggle (API)**
```bash
curl -X POST http://localhost:3333/api/toggles \
  -H "x-admin-token: dev-secret" \
  -H "content-type: application/json" \
  -d '{
    "name": "my-feature",
    "enabled": true,
    "rollout": 50,
    "constraints": { "country": ["US"] }
  }'
```

## **Evaluate Feature**
```bash
curl 'http://localhost:3333/api/evaluate/my-feature?user=john&attrs={"country":"US"}'
```

**Response:**
```json
{ "on": true, "percent": 50, "hashPercent": 42 }
```

## **Manual Rollback**
```bash
curl -X POST http://localhost:3333/api/toggles/my-feature/rollback \
  -H "x-admin-token: dev-secret" \
  -H "content-type: application/json" \
  -d '{"reason": "Errors detected"}'
```

## **Get Metrics**
```bash
curl http://localhost:3333/api/metrics
```

## **Get Sliding-Window Metrics**
```bash
# Last 60 seconds
curl 'http://localhost:3333/api/metrics/window?ms=60000'

# Last 5 minutes
curl 'http://localhost:3333/api/metrics/window?ms=300000'
```

## **Get Audit Log**
```bash
curl http://localhost:3333/api/audit
```

## **Update Toggle Rollout**
```bash
curl -X POST http://localhost:3333/api/toggles \
  -H "x-admin-token: dev-secret" \
  -H "content-type: application/json" \
  -d '{"name": "my-feature", "rollout": 75}'
```

## **Test Suite**
```bash
npm test                   # Run Jest tests
npm run smoke              # Quick smoke test
```

## **Set Custom Admin Token**
```bash
export ADMIN_TOKEN="your-token"
npm start
```

## **Dashboard Tabs**
- **Feature Toggles**: Manage toggles (create, update, rollback)
- **Metrics & Charts**: Real-time exposure and error-rate graphs
- **Audit Log**: History of all changes
- **Test Evaluation**: Simulate feature evaluations

## **Common Workflows**

### Gradual Rollout
1. Create toggle with `rollout: 5`
2. Monitor metrics
3. After 1 hour, update to `rollout: 25`
4. After 2 hours, update to `rollout: 50`
5. After 3 hours, update to `rollout: 100`

### Geo-Targeted Launch
1. Create toggle with `constraints: { country: ["US"] }`, `rollout: 50`
2. Later expand: `constraints: { country: ["US", "CA", "DE"] }`

### A/B Test
1. Create `variant-a` with `rollout: 50`
2. Create `variant-b` with `rollout: 50`
3. In app, evaluate both and show accordingly

## **Error Rate & Auto-Rollback**
- **Checked**: Every 5 seconds
- **Window**: Last 60 seconds
- **Threshold**: 25% error rate
- **Minimum data**: 8 exposures required
- **Action**: Sets `rollout` to 0% if threshold hit

## **File Structure**
```
server.js              → Main Express app & routes
toggleService.js       → Toggle CRUD
trafficRouter.js       → Feature evaluation
timeBucketMetrics.js   → Metrics aggregation
rollbackController.js  → Auto-rollback checker
audit.js              → Audit logging
public/index.html     → Dashboard UI
```

## **Environment Variables**
```bash
ADMIN_TOKEN          # Admin token (default: 'dev-secret')
PORT                 # Server port (default: 3333)
```

## **Troubleshooting**

| Issue | Solution |
|-------|----------|
| Port in use | `pkill -f 'node server.js'` then `npm start` |
| 403 Forbidden | Check admin token in header/query |
| Metrics empty | Simulate traffic in Test Evaluation tab |
| Rollback not triggering | Ensure error_rate >= 25% and exposures >= 8 |

## **Documentation**
- `README.md` — Full documentation
- `GETTING_STARTED.md` — Setup guide with examples

---

**Happy toggling! 🎉**
