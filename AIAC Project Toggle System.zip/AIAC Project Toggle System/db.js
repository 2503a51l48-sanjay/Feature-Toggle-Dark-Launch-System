const { MongoClient } = require('mongodb');

class Database {
  constructor(connectionString) {
    this.connectionString = connectionString || 'mongodb://localhost:27017/aiac_toggle_system';
    this.client = null;
    this.db = null;
  }

  async connect() {
    try {
      this.client = new MongoClient(this.connectionString, {
        serverSelectionTimeoutMS: 5000,
      });
      
      await this.client.connect();
      this.db = this.client.db('aiac_toggle_system');
      
      // Create collections if they don't exist
      await this.initializeCollections();
      console.log('✓ MongoDB connected successfully');
      return true;
    } catch (error) {
      console.error('✗ MongoDB connection failed:', error.message);
      console.warn('⚠ Falling back to file-based storage...');
      return false;
    }
  }

  async initializeCollections() {
    try {
      const collections = await this.db.listCollections().toArray();
      const collectionNames = collections.map(c => c.name);

      // Create toggles collection with indexes
      if (!collectionNames.includes('toggles')) {
        await this.db.createCollection('toggles');
        await this.db.collection('toggles').createIndex({ name: 1 }, { unique: true });
      }

      // Create metrics collection
      if (!collectionNames.includes('metrics')) {
        await this.db.createCollection('metrics');
        await this.db.collection('metrics').createIndex({ feature: 1, timestamp: -1 });
      }

      // Create audit log collection
      if (!collectionNames.includes('audit_logs')) {
        await this.db.createCollection('audit_logs');
        await this.db.collection('audit_logs').createIndex({ timestamp: -1 });
      }

      // Create admin tokens collection (for per-admin tokens stored hashed)
      if (!collectionNames.includes('admin_tokens')) {
        await this.db.createCollection('admin_tokens');
        // index by name for convenience and by createdAt for ordering
        await this.db.collection('admin_tokens').createIndex({ name: 1 });
        await this.db.collection('admin_tokens').createIndex({ createdAt: -1 });
      }

      console.log('✓ Collections initialized');
    } catch (error) {
      console.error('Error initializing collections:', error.message);
    }
  }

  async disconnect() {
    if (this.client) {
      await this.client.close();
      console.log('✓ MongoDB disconnected');
    }
  }

  getDatabase() {
    return this.db;
  }

  isConnected() {
    return this.db !== null;
  }
}

module.exports = Database;
