const fetch = require('node-fetch');

async function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }

async function run(){
  const base = 'http://localhost:3333';
  console.log('Creating sample toggle...');
  await fetch(base + '/api/toggles', {method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({name:'risky-feature', enabled:true, rollout:50, constraints:{country:['US']}})});
  console.log('Simulating traffic and errors to drive rollback...');
  // simulate 30 requests, and count some errors
  for(let i=0;i<30;i++){
    const user = 'user-' + i;
    const res = await fetch(base + '/api/evaluate/risky-feature?user=' + encodeURIComponent(user) + '&attrs=' + encodeURIComponent(JSON.stringify({country: 'US'})));
    const j = await res.json();
    // pretend feature caused error for a few
    if (j.on && i % 3 === 0) {
      await fetch(base + '/api/metrics/error', {method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({feature:'risky-feature'})}).catch(()=>{});
    }
  }
  console.log('Done. Check /api/metrics and /api/toggles to see if rollback occurred.');
}

run().catch(e=>{ console.error(e); process.exit(1); });
