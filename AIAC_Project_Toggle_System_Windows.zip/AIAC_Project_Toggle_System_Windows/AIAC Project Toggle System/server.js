const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const Database = require('./db');
const ToggleService = require('./toggleService');
const TrafficRouter = require('./trafficRouter');
const TimeBucketMetrics = require('./timeBucketMetrics');
const RollbackController = require('./rollbackController');
const AuditLog = require('./audit');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { RateLimiter, createRateLimitMiddleware, createAuthMiddleware } = require('./middleware');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Database initialization
const database = new Database(process.env.MONGODB_URI);
let dbConnected = false;

// Initialize services with either MongoDB or file-based storage
const storeFile = path.join(__dirname, 'toggle-store.json');
let toggleService = new ToggleService(storeFile);
const metrics = new TimeBucketMetrics({ file: require('path').join(__dirname, 'metrics-buckets.jsonl') });
let router = new TrafficRouter(toggleService, metrics);
let rollback = new RollbackController(toggleService, metrics, { 
  windowMs: process.env.METRICS_WINDOW_MS || 60 * 1000, 
  checkInterval: process.env.ROLLBACK_CHECK_INTERVAL || 5000, 
  errorRateThreshold: Number(process.env.ERROR_RATE_THRESHOLD) || 0.25, 
  minExposures: Number(process.env.MIN_EXPOSURES) || 8 
});
const audit = new AuditLog();

// Admin token configuration
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || 'dev-secret';
const rateLimiter = new RateLimiter({ windowMs: 60 * 1000, maxRequests: 200 });

app.use(createRateLimitMiddleware(rateLimiter));

// Verify an admin token: either matches ADMIN_TOKEN or exists in admin_tokens collection (bcrypt hashed)
async function verifyAdminToken(token) {
  if (!token) return false;
  if (token === ADMIN_TOKEN) return true;
  try {
    const db = app.locals.db;
    if (!db) return false;
    const coll = db.collection('admin_tokens');
    const cursor = coll.find({}, { projection: { _id: 1, name: 1, hash: 1 } });
    while (await cursor.hasNext()) {
      const candidate = await cursor.next();
      if (!candidate || !candidate.hash) continue;
      const match = await bcrypt.compare(token, candidate.hash);
      if (match) {
        // update lastUsed
        try { await coll.updateOne({ _id: candidate._id }, { $set: { lastUsed: new Date() } }); } catch (e) {}
        return true;
      }
    }
    return false;
  } catch (e) {
    console.warn('verifyAdminToken error', e && e.message);
    return false;
  }
}

async function checkAdmin(req, res, next){
  const token = req.headers['x-admin-token'] || req.query.admin_token;
  try {
    const ok = await verifyAdminToken(token);
    if (ok) return next();
  } catch (e) {
    console.warn('checkAdmin verify error', e && e.message);
  }
  try {
    // Record forbidden attempt in the audit log (do not store the token value)
    audit.add({
      type: 'forbidden',
      feature: req.params && req.params.name ? req.params.name : null,
      by: req.ip || req.headers['x-forwarded-for'] || 'unknown',
      detail: { path: req.originalUrl, method: req.method, token_provided: !!token }
    });
  } catch (e) {
    console.warn('Failed to record forbidden audit entry:', e && e.message);
  }
  return res.status(403).json({ error: 'forbidden, admin token required' });
}

// Admin API for toggles
app.get('/api/toggles', (req, res) => res.json(toggleService.list()));
app.post('/api/toggles', checkAdmin, async (req, res) => {
  try {
    const t = await toggleService.createOrUpdate(req.body);
    audit.add({ type: 'toggle_update', feature: t.name, by: req.body.by || 'api' , detail: t });
    res.json(t);
  } catch (err) {
    console.error('Error creating/updating toggle:', err.message);
    res.status(500).json({ error: err.message || 'failed to persist toggle' });
  }
});
app.get('/api/toggles/:name', (req, res) => {
  const t = toggleService.get(req.params.name);
  if (!t) return res.status(404).json({error: 'not found'});
  res.json(t);
});

// manual rollback endpoint (admin)
app.post('/api/toggles/:name/rollback', checkAdmin, async (req, res) => {
  const name = req.params.name;
  const t = toggleService.get(name);
  if (!t) return res.status(404).json({ error: 'not found' });
  try {
    await toggleService.setRollout(name, 0);
    audit.add({ type: 'rollback', feature: name, by: req.body.by || 'manual', reason: req.body.reason || 'manual rollback' });
    res.json({ ok: true, feature: name });
  } catch (err) {
    console.error('Rollback failed:', err.message);
    res.status(500).json({ error: err.message || 'rollback failed' });
  }
});

// Helpful GET handler for rollback route: returns 405 and explains the correct usage.
app.get('/api/toggles/:name/rollback', checkAdmin, (req, res) => {
  const name = req.params.name;
  res.status(405).json({
    error: 'method_not_allowed',
    message: 'Use POST to perform a rollback on a toggle. Example: POST /api/toggles/:name/rollback with x-admin-token header and optional JSON body {"by":"ui","reason":"..."}.',
    feature: name,
    allowed: ['POST']
  });
});

// Metrics
app.get('/api/metrics', (req, res) => res.json(metrics.snapshot()));

// record activation
app.post('/api/metrics/activation', (req, res) => {
  const { feature } = req.body || {};
  if (!feature) return res.status(400).json({ error: 'feature required' });
  metrics.countActivation(feature);
  res.json({ ok: true });
});

// record error
app.post('/api/metrics/error', (req, res) => {
  const { feature } = req.body || {};
  if (!feature) return res.status(400).json({ error: 'feature required' });
  metrics.countError(feature);
  res.json({ ok: true });
});

// expose simple Prometheus-like metrics
app.get('/api/metrics/prometheus', (req, res) => {
  const snap = metrics.snapshot();
  const lines = [];
  Object.keys(snap).forEach(f => {
    const d = snap[f];
    lines.push(`# HELP aiac_feature_exposure_total exposures by state`);
    lines.push(`# TYPE aiac_feature_exposure_total counter`);
    lines.push(`aiac_feature_exposure_total{feature="${f}",state="on"} ${d.exposures.on || 0}`);
    lines.push(`aiac_feature_exposure_total{feature="${f}",state="off"} ${d.exposures.off || 0}`);
    lines.push(`# HELP aiac_feature_activation_total activations`);
    lines.push(`aiac_feature_activation_total{feature="${f}"} ${d.activations || 0}`);
    lines.push(`# HELP aiac_feature_errors_total errors`);
    lines.push(`aiac_feature_errors_total{feature="${f}"} ${d.errors || 0}`);
  });
  res.type('text/plain').send(lines.join('\n'));
});

// audit logs
app.get('/api/audit', (req, res) => res.json(audit.list(200)));

// Admin token management endpoints
// Create (rotate) a new admin token and return the plaintext once
app.post('/api/admin/rotate-token', checkAdmin, async (req, res) => {
  try {
    const db = app.locals.db;
    if (!db) return res.status(500).json({ error: 'database not available' });
    const coll = db.collection('admin_tokens');
    const name = req.body && req.body.name ? String(req.body.name).slice(0, 128) : `ui-${Date.now()}`;
    const expiresDays = req.body && Number(req.body.expiresDays) ? Number(req.body.expiresDays) : null;
    const token = crypto.randomBytes(32).toString('hex');
    const hash = await bcrypt.hash(token, 10);
    const doc = { name, hash, createdAt: new Date(), lastUsed: null };
    if (expiresDays) doc.expiresAt = new Date(Date.now() + expiresDays * 24 * 60 * 60 * 1000);
    const r = await coll.insertOne(doc);
    audit.add({ type: 'admin_token_created', by: req.ip || req.headers['x-forwarded-for'] || 'unknown', detail: { id: r.insertedId.toString(), name } });
    // return plaintext token once (caller must store it securely)
    res.json({ id: r.insertedId, name, token });
  } catch (e) {
    console.error('rotate-token failed', e && e.message);
    res.status(500).json({ error: 'rotate failed' });
  }
});

// List admin tokens (metadata only)
app.get('/api/admin/tokens', checkAdmin, async (req, res) => {
  try {
    const db = app.locals.db;
    if (!db) return res.status(500).json({ error: 'database not available' });
    const coll = db.collection('admin_tokens');
    const rows = await coll.find({}, { projection: { hash: 0 } }).sort({ createdAt: -1 }).limit(200).toArray();
    res.json(rows.map(r => ({ id: r._id, name: r.name, createdAt: r.createdAt, lastUsed: r.lastUsed, expiresAt: r.expiresAt })));
  } catch (e) { res.status(500).json({ error: 'failed to list tokens' }); }
});

// Revoke (delete) a token by id
app.delete('/api/admin/tokens/:id', checkAdmin, async (req, res) => {
  try {
    const db = app.locals.db;
    if (!db) return res.status(500).json({ error: 'database not available' });
    const ObjectId = require('mongodb').ObjectId;
    const id = req.params.id;
    const coll = db.collection('admin_tokens');
    const r = await coll.deleteOne({ _id: ObjectId(id) });
    audit.add({ type: 'admin_token_revoked', by: req.ip || req.headers['x-forwarded-for'] || 'unknown', detail: { id } });
    res.json({ ok: true, deleted: r.deletedCount });
  } catch (e) { res.status(500).json({ error: 'failed to revoke token' }); }
});

// Health check and database status
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    database: dbConnected ? 'connected' : 'file-based',
    uptime: process.uptime(),
    timestamp: new Date().toISOString()
  });
});

// Database status endpoint
app.get('/api/status', (req, res) => {
  res.json({
    server: 'running',
    database: {
      connected: dbConnected,
      type: dbConnected ? 'MongoDB' : 'File-based JSON',
      uri: dbConnected ? process.env.MONGODB_URI : 'local file storage'
    },
    toggles: toggleService.list().length,
    adminToken: ADMIN_TOKEN !== 'dev-secret' ? 'custom' : 'default (dev-secret)',
    environment: process.env.NODE_ENV || 'development'
  });
});

// windowed stats endpoint
app.get('/api/metrics/window', (req, res) => {
  const ms = Number(req.query.ms) || 60 * 1000;
  res.json(metrics.windowStats(ms));
});

// AI suggestion endpoint - simple rule-based suggestions based on recent metrics
app.get('/api/ai/suggestions', (req, res) => {
  try {
    const ms = Number(req.query.ms) || 60 * 1000;
    const featureFilter = req.query.feature;
    const stats = metrics.windowStats(ms);
    const errorThreshold = Number(process.env.AI_ERROR_RATE_THRESHOLD) || 0.25;
    const minExposures = Number(process.env.AI_MIN_EXPOSURES) || 8;

    const results = Object.entries(stats).map(([f, m]) => {
      const on = (m.exposures && m.exposures.on) || 0;
      const off = (m.exposures && m.exposures.off) || 0;
      const errors = m.errors || 0;
      const exposures = on + off;
      const errorRate = exposures > 0 ? (errors / exposures) : 0;
      const suggestion = (exposures >= minExposures && errorRate > errorThreshold) ? 'rollback' : 'ok';
      const reason = suggestion === 'rollback' ? `error rate ${(errorRate * 100).toFixed(1)}% (threshold ${(errorThreshold * 100).toFixed(1)}%)` : 'within threshold';
      return { feature: f, exposures, on, off, errors, errorRate, suggestion, reason };
    }).filter(x => !featureFilter || x.feature === featureFilter);

    res.json(results);
  } catch (e) {
    console.error('AI suggestion error', e.message);
    res.status(500).json({ error: 'ai suggestion failed' });
  }
});

// Evaluate feature for a user (simulate request routing)
app.get('/api/evaluate/:feature', (req, res) => {
  const user = req.query.user || 'anon';
  const attrs = req.query.attrs ? JSON.parse(req.query.attrs) : {};
  const result = router.evaluate(req.params.feature, user, attrs);
  res.json(result);
});

// Serve a minimal frontend
app.use('/', express.static(path.join(__dirname, 'public')));

// Simple API root to help browsers/users visiting /api
app.get('/api', (req, res) => {
  const info = {
    name: 'AIAC Toggle System API',
    version: '0.1.0',
    description: 'Feature toggle API for the AIAC Toggle System',
    endpoints: {
      health: '/api/health',
      status: '/api/status',
      toggles: '/api/toggles',
      metrics: '/api/metrics',
      evaluate: '/api/evaluate/:feature',
      audit: '/api/audit'
    }
  };

  // If the client prefers HTML (browser), return a small human-friendly page
  const accept = (req.get('Accept') || '').toLowerCase();
  if (accept.includes('text/html')) {
    const endpointsHtml = Object.entries(info.endpoints).map(([k, v]) => `<li><strong>${k}</strong>: <a href="${v}">${v}</a></li>`).join('');
    return res.send(`<!doctype html>
      <html>
      <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width,initial-scale=1" />
        <title>${info.name}</title>
        <style>body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;color:#111;background:#f7fafc;padding:24px}a{color:#2563eb}code{background:#fff;padding:2px 6px;border-radius:4px;border:1px solid #e5e7eb}</style>
      </head>
      <body>
        <h1>${info.name}</h1>
        <p>${info.description}</p>
        <p>Version: <code>${info.version}</code></p>
        <h2>Endpoints</h2>
        <ul>
          ${endpointsHtml}
        </ul>
        <p>Open the <a href="/">dashboard</a>.</p>
      </body>
      </html>`);
  }

  // Default to JSON for API clients
  res.json(info);
});

const PORT = process.env.PORT || 3333;

// Start server with database connection
async function startServer() {
  try {
    // Try to connect to MongoDB
    dbConnected = await database.connect();
    
    if (dbConnected) {
      const db = database.getDatabase();
      // Add database reference to app for use in routes if needed
      app.locals.db = db;
      console.log('📊 Using MongoDB for data persistence');

      // Ensure there's at least one admin token entry for programmatic management if an env token was provided
      try {
        const adminColl = db.collection('admin_tokens');
        const cnt = await adminColl.countDocuments();
        if (cnt === 0 && ADMIN_TOKEN && ADMIN_TOKEN !== 'dev-secret') {
          const hash = await bcrypt.hash(ADMIN_TOKEN, 10);
          await adminColl.insertOne({ name: 'env-provided-initial', hash, createdAt: new Date(), lastUsed: null });
          console.log('🔐 Migrated ADMIN_TOKEN from env into admin_tokens collection (hashed).');
        }
      } catch (e) {
        console.warn('Could not migrate ADMIN_TOKEN into DB:', e && e.message);
      }

      try {
        // Swap in Mongo-backed toggle service (keeps in-memory cache for fast reads)
        const ToggleServiceMongo = require('./toggleService.mongo');
        toggleService = await ToggleServiceMongo.create(db);
        // Recreate router and rollback with the DB-backed toggle service
        router = new TrafficRouter(toggleService, metrics);
        rollback = new RollbackController(toggleService, metrics, { 
          windowMs: process.env.METRICS_WINDOW_MS || 60 * 1000, 
          checkInterval: process.env.ROLLBACK_CHECK_INTERVAL || 5000, 
          errorRateThreshold: Number(process.env.ERROR_RATE_THRESHOLD) || 0.25, 
          minExposures: Number(process.env.MIN_EXPOSURES) || 8 
        });
        console.log('🔁 ToggleService switched to MongoDB-backed implementation');
      } catch (e) {
        console.error('Failed to initialize Mongo-backed ToggleService:', e.message);
      }
    } else {
      console.log('📁 Using file-based storage (fallback mode)');
    }

    const server = app.listen(PORT, () => {
      console.log(`\n🚀 Feature Toggle & Dark Launch System running on http://localhost:${PORT}`);
      console.log(`📌 Admin Token: ${ADMIN_TOKEN}`);
      console.log(`🗄️  Database: ${dbConnected ? 'MongoDB' : 'File-based'}`);
      console.log(`\n✨ Dashboard: http://localhost:${PORT}`);
    });

    // Graceful shutdown
    process.on('SIGINT', async () => {
      console.log('\n📍 Shutting down gracefully...');
      server.close(async () => {
        if (dbConnected) {
          await database.disconnect();
        }
        process.exit(0);
      });
    });

  } catch (error) {
    console.error('❌ Failed to start server:', error.message);
    process.exit(1);
  }
}

startServer();
