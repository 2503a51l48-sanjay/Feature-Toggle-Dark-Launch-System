const fs = require('fs');

class ToggleService {
  constructor(storeFile) {
    this.storeFile = storeFile;
    this.toggles = {};
    this._load();
  }

  _load() {
    try {
      if (fs.existsSync(this.storeFile)) {
        const raw = fs.readFileSync(this.storeFile, 'utf8');
        this.toggles = JSON.parse(raw);
      } else {
        this.toggles = {};
      }
    } catch (e) {
      console.error('failed to load toggles', e);
      this.toggles = {};
    }
  }

  _save() {
    try {
      fs.writeFileSync(this.storeFile, JSON.stringify(this.toggles, null, 2));
    } catch (e) {
      console.error('failed to save toggles', e);
    }
  }

  list() {
    return Object.values(this.toggles);
  }

  get(name) {
    return this.toggles[name];
  }

  createOrUpdate(spec) {
    // spec: {name, enabled, rollout: 0-100, constraints: {country: ['US']}, createdAt}
    const now = Date.now();
    const existing = this.toggles[spec.name] || {};
    const updated = Object.assign({
      name: spec.name,
      enabled: spec.enabled === undefined ? true : spec.enabled,
      rollout: spec.rollout == null ? 0 : spec.rollout,
      constraints: spec.constraints || {},
      createdAt: existing.createdAt || now,
      updatedAt: now
    }, spec);
    this.toggles[spec.name] = updated;
    this._save();
    return updated;
  }

  setRollout(name, percent) {
    const t = this.toggles[name];
    if (!t) return null;
    t.rollout = Math.max(0, Math.min(100, percent));
    t.updatedAt = Date.now();
    this._save();
    return t;
  }
}

module.exports = ToggleService;
