const crypto = require('crypto');

class TrafficRouter {
  constructor(toggleService, metrics) {
    this.toggleService = toggleService;
    this.metrics = metrics;
  }

  _hashToPercent(key) {
    const h = crypto.createHash('sha1').update(String(key)).digest('hex');
    // take first 8 chars -> 32-bit value
    const val = parseInt(h.substring(0, 8), 16);
    return (val % 100) + 1; // 1..100
  }

  _matchesConstraints(constraints, attrs) {
    if (!constraints) return true;
    if (constraints.country) {
      if (!attrs.country) return false;
      if (!constraints.country.includes(attrs.country)) return false;
    }
    // add more constraints as needed
    return true;
  }

  evaluate(featureName, userId, attrs = {}) {
    const t = this.toggleService.get(featureName);
    const exposure = { feature: featureName, user: userId, attrs };
    if (!t || !t.enabled) {
      this.metrics.countExposure(featureName, 'off');
      return { on: false, reason: 'disabled' };
    }

    if (!this._matchesConstraints(t.constraints, attrs)) {
      this.metrics.countExposure(featureName, 'off');
      return { on: false, reason: 'constraint_mismatch' };
    }

    const pct = this._hashToPercent(userId);
    const on = pct <= (t.rollout || 0);
    this.metrics.countExposure(featureName, on ? 'on' : 'off');
    return { on, percent: t.rollout, hashPercent: pct };
  }
}

module.exports = TrafficRouter;
