/**
 * Unit and integration tests for AIAC Toggle System
 */

const ToggleService = require('../toggleService');
const TrafficRouter = require('../trafficRouter');
const TimeBucketMetrics = require('../timeBucketMetrics');
const RollbackController = require('../rollbackController');
const fs = require('fs');
const path = require('path');

// Test helpers
function tempFile(name) {
  return path.join('/tmp', `aiac-test-${name}-${Date.now()}.json`);
}

describe('ToggleService', () => {
  let service;

  beforeEach(() => {
    service = new ToggleService(tempFile('toggles'));
  });

  test('creates and retrieves a toggle', () => {
    const t = service.createOrUpdate({ name: 'test-feature', enabled: true, rollout: 50 });
    expect(t.name).toBe('test-feature');
    expect(t.rollout).toBe(50);
    expect(t.enabled).toBe(true);

    const fetched = service.get('test-feature');
    expect(fetched.name).toBe('test-feature');
  });

  test('updates rollout percentage', () => {
    service.createOrUpdate({ name: 'feat1', enabled: true, rollout: 10 });
    const updated = service.setRollout('feat1', 75);
    expect(updated.rollout).toBe(75);
  });

  test('lists all toggles', () => {
    service.createOrUpdate({ name: 'feat1', enabled: true, rollout: 10 });
    service.createOrUpdate({ name: 'feat2', enabled: false, rollout: 0 });
    const list = service.list();
    expect(list.length).toBe(2);
  });

  test('persists toggles to disk', () => {
    const file = tempFile('persist');
    const svc = new ToggleService(file);
    svc.createOrUpdate({ name: 'persist-test', enabled: true, rollout: 30 });
    
    // Reload and verify
    const svc2 = new ToggleService(file);
    const t = svc2.get('persist-test');
    expect(t.name).toBe('persist-test');
    expect(t.rollout).toBe(30);
  });
});

describe('TrafficRouter', () => {
  let router, toggleService, metrics;

  beforeEach(() => {
    toggleService = new ToggleService(tempFile('router-toggles'));
    metrics = new TimeBucketMetrics({ file: tempFile('router-metrics') });
    router = new TrafficRouter(toggleService, metrics);
  });

  test('evaluates disabled feature as off', () => {
    toggleService.createOrUpdate({ name: 'disabled', enabled: false, rollout: 50 });
    const result = router.evaluate('disabled', 'user-1', {});
    expect(result.on).toBe(false);
    expect(result.reason).toBe('disabled');
  });

  test('evaluates with rollout percentage', () => {
    toggleService.createOrUpdate({ name: 'rollout-test', enabled: true, rollout: 50 });
    const result = router.evaluate('rollout-test', 'user-1', {});
    expect(typeof result.on).toBe('boolean');
    expect(result.percent).toBe(50);
  });

  test('respects country constraints', () => {
    toggleService.createOrUpdate({
      name: 'geo-feature',
      enabled: true,
      rollout: 100,
      constraints: { country: ['US', 'CA'] }
    });
    const resultUS = router.evaluate('geo-feature', 'user-1', { country: 'US' });
    const resultUK = router.evaluate('geo-feature', 'user-2', { country: 'UK' });
    expect(resultUS.on).toBe(true);
    expect(resultUK.on).toBe(false);
    expect(resultUK.reason).toBe('constraint_mismatch');
  });

  test('deterministic routing for same user', () => {
    toggleService.createOrUpdate({ name: 'deterministic', enabled: true, rollout: 50 });
    const result1 = router.evaluate('deterministic', 'user-123', {});
    const result2 = router.evaluate('deterministic', 'user-123', {});
    expect(result1.on).toBe(result2.on);
  });

  test('counts exposures in metrics', () => {
    toggleService.createOrUpdate({ name: 'metrics-test', enabled: true, rollout: 100 });
    router.evaluate('metrics-test', 'user-1', {});
    router.evaluate('metrics-test', 'user-2', {});
    const snap = metrics.snapshot();
    expect(snap['metrics-test'].exposures.on).toBeGreaterThan(0);
  });
});

describe('TimeBucketMetrics', () => {
  let metrics;

  beforeEach(() => {
    metrics = new TimeBucketMetrics({ file: tempFile('metrics'), bucketSizeMs: 1000 });
  });

  test('counts exposures', () => {
    metrics.countExposure('feature1', 'on');
    metrics.countExposure('feature1', 'off');
    const snap = metrics.snapshot();
    expect(snap['feature1'].exposures.on).toBe(1);
    expect(snap['feature1'].exposures.off).toBe(1);
  });

  test('counts errors and activations', () => {
    metrics.countError('feature2');
    metrics.countActivation('feature2');
    const snap = metrics.snapshot();
    expect(snap['feature2'].errors).toBe(1);
    expect(snap['feature2'].activations).toBe(1);
  });

  test('computes windowed stats', () => {
    metrics.countExposure('feature3', 'on');
    metrics.countExposure('feature3', 'off');
    metrics.countError('feature3');
    const window = metrics.windowStats(10000); // 10s window
    expect(window['feature3'].exposures.on).toBe(1);
    expect(window['feature3'].exposures.off).toBe(1);
    expect(window['feature3'].errors).toBe(1);
  });

  test('persists buckets to file', () => {
    const file = tempFile('bucket-persist');
    const m = new TimeBucketMetrics({ file });
    m.countExposure('persist-feature', 'on');
    
    const m2 = new TimeBucketMetrics({ file });
    const snap = m2.snapshot();
    expect(snap['persist-feature'].exposures.on).toBe(1);
  });
});

describe('RollbackController', () => {
  let controller, toggleService, metrics;

  beforeEach(() => {
    toggleService = new ToggleService(tempFile('rollback-toggles'));
    metrics = new TimeBucketMetrics({ file: tempFile('rollback-metrics') });
    controller = new RollbackController(toggleService, metrics, {
      windowMs: 10000,
      checkInterval: 100,
      errorRateThreshold: 0.2,
      minExposures: 5
    });
  });

  test('triggers rollback on high error rate', (done) => {
    toggleService.createOrUpdate({ name: 'risky', enabled: true, rollout: 100 });
    
    // Simulate traffic with errors
    for (let i = 0; i < 10; i++) {
      metrics.countExposure('risky', 'on');
    }
    for (let i = 0; i < 3; i++) {
      metrics.countError('risky');
    }
    
    // Wait for rollback to trigger
    setTimeout(() => {
      const t = toggleService.get('risky');
      expect(t.rollout).toBe(0);
      done();
    }, 200);
  });

  test('does not rollback with low error rate', (done) => {
    toggleService.createOrUpdate({ name: 'safe', enabled: true, rollout: 100 });
    
    // Simulate traffic with few errors
    for (let i = 0; i < 20; i++) {
      metrics.countExposure('safe', 'on');
    }
    for (let i = 0; i < 1; i++) {
      metrics.countError('safe');
    }
    
    setTimeout(() => {
      const t = toggleService.get('safe');
      expect(t.rollout).toBe(100); // Not rolled back
      done();
    }, 200);
  });
});

// Integration test
describe('Integration: Full flow', () => {
  test('create toggle, evaluate, trigger rollback', (done) => {
    const toggleService = new ToggleService(tempFile('int-toggles'));
    const metrics = new TimeBucketMetrics({ file: tempFile('int-metrics') });
    const router = new TrafficRouter(toggleService, metrics);
    const controller = new RollbackController(toggleService, metrics, {
      windowMs: 10000,
      checkInterval: 50,
      errorRateThreshold: 0.15,
      minExposures: 8
    });

    // Create feature
    toggleService.createOrUpdate({ name: 'integration-test', enabled: true, rollout: 100 });

    // Simulate traffic
    for (let i = 0; i < 20; i++) {
      const result = router.evaluate('integration-test', `user-${i}`, {});
      if (result.on) metrics.countActivation('integration-test');
    }

    // Simulate errors (> 15%)
    for (let i = 0; i < 4; i++) {
      metrics.countError('integration-test');
    }

    // Wait for rollback
    setTimeout(() => {
      const t = toggleService.get('integration-test');
      expect(t.rollout).toBe(0);
      const snap = metrics.snapshot();
      expect(snap['integration-test'].errors).toBeGreaterThan(0);
      done();
    }, 150);
  });
});
