# AIAC Toggle System — Complete Feature Toggle & Dark Launch Platform

A production-ready fullstack feature toggle system with **dark launch**, **automated rollback**, **real-time monitoring**, and a beautiful dashboard UI. Built with Node.js/Express and modern web technologies.

---

## 🎯 Features

### Core Capabilities
- **Feature Toggles**: Create, manage, and deploy toggles with granular rollout control (0-100%).
- **Dark Launch**: Safely roll out risky features to a percentage of users with deterministic, consistent routing.
- **Audience Constraints**: Define rules (country, attributes) to target specific user segments.
- **Automated Rollback**: Monitor error rates and automatically roll back features when thresholds are breached.
- **Audit Logging**: Full history of toggle changes and rollback events.
- **Real-time Metrics**: Sliding-window statistics with exposures, activations, and error tracking.

### Admin Dashboard
- **Toggle Manager**: Create, update, and rollback features via an intuitive UI.
- **Charts & Analytics**: Real-time exposure and error-rate visualizations (Chart.js).
- **Audit Viewer**: Track all administrative actions and system events.
- **Test Evaluator**: Simulate feature evaluations for different users and attributes.
- **Admin Authentication**: Token-based access control for sensitive operations.

### Technical Features
- **Persistent Storage**: Toggle definitions and metrics persisted to disk (JSONL).
- **Time-Bucket Metrics**: Fixed 10-second intervals for accurate sliding-window error-rate calculations.
- **Rate Limiting**: API rate-limiting to prevent abuse.
- **Deterministic Routing**: SHA1-based hashing ensures consistent user assignments.
- **REST API**: Full-featured API for integration with external systems.

---

## 🚀 Quick Start

### Installation

```bash
cd '/Users/sanjayduduka/AIAC Project Toggle System'
npm install
```

### Start the Server

```bash
npm start
# or for development with auto-reload:
# npm run dev
```

The server runs on **http://localhost:3333** by default.

### Open the Dashboard

Visit: **http://localhost:3333**

You'll see a beautiful, responsive dashboard with tabs for toggles, metrics, audit logs, and testing.

---

## 🔐 Admin Authentication

The system uses a simple **token-based authentication** for admin operations.

### Set Admin Token

**Environment variable (recommended for production):**
```bash
export ADMIN_TOKEN="your-secure-token-here"
npm start
```

**Default (local development only):**
```bash
npm start
# Default token is 'dev-secret'
```

### In the Dashboard

1. Click the "Admin Token" field in the header.
2. Paste your token.
3. Click "Save" — the token is stored in localStorage.
4. All admin operations (create, update, rollback) will use this token.

---

## 📊 API Reference

### Toggles

#### Get All Toggles
```http
GET /api/toggles
```

#### Get Specific Toggle
```http
GET /api/toggles/:name
```

#### Create or Update Toggle
```http
POST /api/toggles
x-admin-token: <token>
Content-Type: application/json

{
  "name": "risky-feature",
  "enabled": true,
  "rollout": 25,
  "constraints": {
    "country": ["US", "CA"]
  }
}
```

#### Manual Rollback
```http
POST /api/toggles/:name/rollback
x-admin-token: <token>
Content-Type: application/json

{
  "by": "manual",
  "reason": "Unexpected errors detected"
}
```

### Evaluation

#### Evaluate Feature for User
```http
GET /api/evaluate/:feature?user=<userId>&attrs=<JSON>
```

**Example:**
```http
GET /api/evaluate/risky-feature?user=user-123&attrs={"country":"US"}
```

**Response:**
```json
{
  "on": true,
  "percent": 25,
  "hashPercent": 42,
  "reason": "evaluated"
}
```

### Metrics

#### Get All-Time Metrics
```http
GET /api/metrics
```

**Response:**
```json
{
  "risky-feature": {
    "exposures": { "on": 150, "off": 450 },
    "activations": 120,
    "errors": 8
  }
}
```

#### Get Sliding-Window Metrics (default: 60s)
```http
GET /api/metrics/window?ms=60000
```

#### Prometheus-Compatible Metrics
```http
GET /api/metrics/prometheus
```

Outputs metrics in Prometheus text format for integration with monitoring systems.

### Audit Log

#### Get Audit Entries
```http
GET /api/audit
```

**Response:**
```json
[
  {
    "type": "rollback",
    "feature": "risky-feature",
    "by": "manual",
    "reason": "Unexpected errors detected",
    "timestamp": 1763290262399
  },
  {
    "type": "toggle_update",
    "feature": "risky-feature",
    "by": "ui",
    "detail": { ... },
    "timestamp": 1763290196268
  }
]
```

---

## 🛠 Configuration

Edit the rollback controller options in `server.js`:

```javascript
const rollback = new RollbackController(toggleService, metrics, {
  windowMs: 60 * 1000,          // 60s sliding window
  checkInterval: 5000,          // Check every 5s
  errorRateThreshold: 0.25,     // Rollback at 25% error rate
  minExposures: 8               // Require at least 8 exposures before evaluating
});
```

---

## 📁 Project Structure

```
AIAC Project Toggle System/
├── server.js                    # Express app, API routes, admin auth
├── toggleService.js             # Toggle CRUD & persistence
├── trafficRouter.js             # Feature evaluation & routing logic
├── timeBucketMetrics.js         # Time-bucket metrics aggregation
├── rollbackController.js         # Automated rollback (background job)
├── audit.js                     # Audit logging
├── middleware.js                # Rate limiting & auth helpers
├── public/
│   └── index.html               # Beautiful dashboard UI (Tailwind CSS)
├── __tests__/
│   └── all.test.js              # Jest unit/integration tests
├── smoke-test.js                # Quick smoke test script
├── toggle-store.json            # Persisted toggles
├── metrics-buckets.jsonl        # Time-bucket metrics (JSONL)
├── audit-log.json               # Audit entries
├── package.json
├── jest.config.js
└── README.md                    # This file
```

---

## 🧪 Testing

### Run Unit & Integration Tests
```bash
npm test
```

### Run Smoke Tests
```bash
npm run smoke
```

Smoke tests create a sample toggle, simulate traffic, and verify the system works end-to-end.

### Manual Testing with curl

```bash
# Create a toggle
curl -X POST http://localhost:3333/api/toggles \
  -H "x-admin-token: dev-secret" \
  -H "content-type: application/json" \
  -d '{"name":"my-feature","enabled":true,"rollout":30,"constraints":{"country":["US"]}}'

# Evaluate for a user
curl "http://localhost:3333/api/evaluate/my-feature?user=user-123&attrs={\"country\":\"US\"}"

# Get metrics
curl http://localhost:3333/api/metrics

# Trigger rollback
curl -X POST http://localhost:3333/api/toggles/my-feature/rollback \
  -H "x-admin-token: dev-secret" \
  -H "content-type: application/json" \
  -d '{"reason":"Test rollback"}'
```

---

## 🎓 Usage Examples

### Example 1: Gradual Rollout

```javascript
// Create a feature starting at 5%
POST /api/toggles
{
  "name": "new-checkout",
  "enabled": true,
  "rollout": 5,
  "constraints": {}
}

// Monitor metrics for 1 hour, then increase
POST /api/toggles
{
  "name": "new-checkout",
  "rollout": 25
}

// Continue ramping up...
POST /api/toggles
{
  "name": "new-checkout",
  "rollout": 50
}

// Finally go to 100%
POST /api/toggles
{
  "name": "new-checkout",
  "rollout": 100
}
```

### Example 2: Geo-Targeted Feature

```javascript
// Roll out only to US and Canada initially
POST /api/toggles
{
  "name": "beta-feature",
  "enabled": true,
  "rollout": 50,
  "constraints": {
    "country": ["US", "CA"]
  }
}

// Later expand to EU
POST /api/toggles
{
  "name": "beta-feature",
  "rollout": 50,
  "constraints": {
    "country": ["US", "CA", "DE", "FR", "GB"]
  }
}
```

### Example 3: Automatic Rollback Scenario

```javascript
// Enable a risky feature at 50%
POST /api/toggles
{
  "name": "risky-algorithm",
  "enabled": true,
  "rollout": 50
}

// The system monitors errors in a 60s sliding window.
// If error rate exceeds 25% with at least 8 exposures,
// it AUTOMATICALLY rolls back to 0%.
// You'll see an audit entry:
// { "type": "rollback", "feature": "risky-algorithm", "by": "automatic", ... }
```

---

## 📈 Metrics & Monitoring

### Time-Bucket Aggregation

Metrics are aggregated into **10-second buckets** for efficient sliding-window calculations.

- **Exposures**: Count of users who saw the feature (on/off).
- **Activations**: Count of users who actually used the feature.
- **Errors**: Count of errors while feature was active.

### Error Rate Calculation

```
error_rate = errors / exposures (in the sliding window)
```

**Rollback threshold:** 25% error rate (configurable).
**Minimum data:** 8 exposures required before evaluating.

### Accessing Metrics Programmatically

```javascript
// All-time aggregation
GET /api/metrics

// Last 60 seconds
GET /api/metrics/window?ms=60000

// Last 5 minutes
GET /api/metrics/window?ms=300000

// Prometheus format (for Grafana/Prometheus integration)
GET /api/metrics/prometheus
```

---

## 🔒 Security Considerations

### Current Implementation (Development)
- **Token-based auth**: Simple header-based token (`x-admin-token`).
- **Rate limiting**: 200 requests per minute per IP.
- **CORS enabled**: Allows requests from any origin (configurable).

### Production Recommendations
1. **Use HTTPS/TLS** for all API communication.
2. **Upgrade authentication**: OAuth 2.0, JWT, or mTLS.
3. **Restrict CORS**: Only allow trusted origins.
4. **Database**: Replace file-based persistence with a database (PostgreSQL, MongoDB).
5. **Monitoring**: Integrate with production APM (DataDog, New Relic).
6. **Audit**: Persist audit logs to a secure backend.
7. **Rate limiting**: Use a distributed solution (Redis) for multi-instance setups.

---

## 🚦 Status & Roadmap

### Completed ✓
- [x] Core toggle service with persistence
- [x] Deterministic traffic routing
- [x] Time-bucket metrics aggregation
- [x] Automated rollback controller
- [x] Beautiful admin dashboard (Tailwind CSS)
- [x] REST API with admin auth
- [x] Audit logging
- [x] Rate limiting
- [x] Smoke tests and basic unit tests

### Future Enhancements 📋
- [ ] Multi-instance support (Redis-backed metrics & toggles)
- [ ] Advanced audience targeting (user attributes, cohorts, A/B testing)
- [ ] Canary deployments with gradual rollout strategies
- [ ] Incident response automation (Slack/email notifications)
- [ ] Experiment framework (A/B testing with statistical significance)
- [ ] GraphQL API
- [ ] Mobile app for mobile-friendly toggle management
- [ ] Integration with CI/CD pipelines (GitHub Actions, GitLab CI)

---

## 🐛 Troubleshooting

### Server won't start
**Error:** `Address already in use`
```bash
# Kill existing process
pkill -f 'node server.js'
npm start
```

### Admin token not working
**Check:**
1. Token is set correctly: `echo $ADMIN_TOKEN` or check dashboard localStorage.
2. Token is passed in header: `-H "x-admin-token: <token>"` or in query: `?admin_token=<token>`.
3. Restart server if you changed `ADMIN_TOKEN` env var.

### Metrics not showing
**Check:**
1. Generate traffic: Use the "Test Evaluation" tab to simulate requests.
2. Wait 10+ seconds: Metrics are aggregated every 10 seconds.
3. Check file exists: `ls -la metrics-buckets.jsonl`.

### Rollback not triggering
**Check:**
1. Error rate is high enough: `(errors / exposures) >= 0.25`.
2. Minimum exposures met: At least 8 exposures in the 60s window.
3. Check logs: `tail -f server.log` for rollback messages.

---

## 📚 Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    User Dashboard (UI)                      │
│              (Tailwind CSS + Chart.js + Fetch)              │
└────────────────────┬────────────────────────────────────────┘
                     │
┌────────────────────v────────────────────────────────────────┐
│                  Express.js Server                           │
│  (Rate Limiting → Auth → Route Handler → Response)          │
└──────┬──────────────────────┬──────────────────┬────────────┘
       │                      │                  │
   ┌───v────┐       ┌────────v────────┐  ┌─────v──────┐
   │ Toggles │       │     Metrics     │  │   Audit    │
   │(persist)│       │(time buckets)   │  │   Logs     │
   └─────────┘       └─────────────────┘  └────────────┘
       │                      │
   ┌───v──────────────────────v──────┐
   │   Deterministic Router + RC      │
   │ (Evaluation & Rollback Control)  │
   └───────────────────────────────────┘
```

---

## 💬 Support & Contribution

For issues or feature requests, check the project structure and test files. The codebase is documented and modular for easy extension.

---

## 📄 License

MIT License — Feel free to use, modify, and distribute.

---

## 🎉 Summary

You now have a **production-ready feature toggle system** with:
- ✅ Beautiful admin dashboard
- ✅ Real-time metrics and charts
- ✅ Automated rollback on errors
- ✅ Audit logging and compliance
- ✅ REST API for integration
- ✅ Token-based admin authentication
- ✅ Rate limiting and security

**Happy toggling! 🚀**
