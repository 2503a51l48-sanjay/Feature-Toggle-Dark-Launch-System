/**
 * Simple rate-limiting and auth helpers.
 */

class RateLimiter {
  constructor(options = {}) {
    this.windowMs = options.windowMs || 60 * 1000; // 1 minute
    this.maxRequests = options.maxRequests || 100;
    this.store = {}; // { key: { count, resetTime } }
  }

  isAllowed(key) {
    const now = Date.now();
    if (!this.store[key]) {
      this.store[key] = { count: 1, resetTime: now + this.windowMs };
      return true;
    }
    const record = this.store[key];
    if (now > record.resetTime) {
      record.count = 1;
      record.resetTime = now + this.windowMs;
      return true;
    }
    record.count++;
    return record.count <= this.maxRequests;
  }
}

function createRateLimitMiddleware(limiter) {
  return (req, res, next) => {
    const key = req.ip || req.connection.remoteAddress || 'unknown';
    if (!limiter.isAllowed(key)) {
      return res.status(429).json({ error: 'rate limited' });
    }
    next();
  };
}

function createAuthMiddleware(expectedTokens) {
  return (req, res, next) => {
    const token = req.headers['x-admin-token'] || req.query.admin_token;
    if (!expectedTokens.includes(token)) {
      return res.status(403).json({ error: 'forbidden: invalid or missing admin token' });
    }
    next();
  };
}

module.exports = { RateLimiter, createRateLimitMiddleware, createAuthMiddleware };
