# AIAC Toggle System — Getting Started Guide

## 📦 What You Have

A **complete, production-ready feature toggle platform** with:

### ✨ Features Implemented
- ✅ **Feature Toggle Service**: Create, update, delete toggles with persistent storage
- ✅ **Dark Launch & Rollout**: Deterministic routing with percentage-based rollout (0-100%)
- ✅ **Audience Constraints**: Target by country, attributes, or custom rules
- ✅ **Automated Rollback**: Monitors error rates and automatically rolls back risky features
- ✅ **Real-time Metrics**: Time-bucket aggregation with sliding-window stats
- ✅ **Beautiful Dashboard**: Responsive Tailwind CSS UI with charts, audit logs, and controls
- ✅ **REST API**: Full-featured API for programmatic integration
- ✅ **Admin Authentication**: Token-based security for protected endpoints
- ✅ **Rate Limiting**: Per-IP request rate limiting (200 req/min)
- ✅ **Audit Logging**: Complete history of changes and rollback events
- ✅ **Tests**: Unit/integration tests and smoke test scripts

---

## 🚀 Quick Start (2 minutes)

### 1. Start the Server
```bash
cd '/Users/sanjayduduka/AIAC Project Toggle System'
npm install
npm start
```

Server runs on **http://localhost:3333**

### 2. Open Dashboard
Visit **http://localhost:3333** in your browser.

You'll see:
- **Feature Toggles tab**: List of all toggles with sliders and controls
- **Metrics & Charts tab**: Real-time exposure and error rate graphs
- **Audit Log tab**: History of all changes
- **Test Evaluation tab**: Simulate feature evaluations

### 3. Create Your First Toggle
In the dashboard:
1. Click "Feature Toggles" tab
2. Fill in the form:
   - **Name**: `my-risky-feature`
   - **Rollout**: `10` (10%)
   - **Countries**: `US,CA` (optional)
3. Click "Create Toggle"

Done! The feature is now live at 10% to users in US/CA.

### 4. Simulate Traffic
In the "Test Evaluation" tab:
1. Enter `user-123` as User ID
2. Keep feature as `my-risky-feature`
3. Keep country as `US`
4. Click "Evaluate"

You'll see: `{"on": true, "percent": 10, ...}` or `{"on": false}` depending on the hash.

### 5. Monitor Metrics
Click "Metrics & Charts" to see:
- Exposure counts (who saw the feature)
- Error rates (if you simulate errors)
- Real-time stats table

---

## 🔐 Admin Authentication

### Option 1: Environment Variable (Production)
```bash
export ADMIN_TOKEN="your-secret-token-here"
npm start
```

### Option 2: Default Token (Development)
```bash
npm start
# Uses default token: 'dev-secret'
```

### Option 3: In Dashboard
1. Open dashboard at http://localhost:3333
2. Click "Admin Token" input in the header
3. Paste token: `dev-secret`
4. Click "Save"

All admin operations (create, update, rollback) will use this token.

---

## 📊 Common Use Cases

### Use Case 1: Gradual Rollout

**Goal**: Roll out a new feature safely over 24 hours

**Steps**:
```
Hour 0:   Create toggle with rollout: 5%
Hour 6:   Update to rollout: 25%
Hour 12:  Update to rollout: 50%
Hour 18:  Update to rollout: 75%
Hour 24:  Update to rollout: 100%
```

Monitoring: Watch error rates in Metrics tab. If errors spike, click "Rollback" to disable instantly.

### Use Case 2: Geo-Targeted Launch

**Goal**: Launch feature only to US users first

**Create toggle with**:
```json
{
  "name": "new-checkout",
  "enabled": true,
  "rollout": 50,
  "constraints": { "country": ["US"] }
}
```

Later expand to EU:
```json
{
  "constraints": { "country": ["US", "CA", "DE", "FR", "GB"] }
}
```

### Use Case 3: A/B Test Setup

**Create two toggles**:
```json
{ "name": "variant-a", "rollout": 50 }
{ "name": "variant-b", "rollout": 50 }
```

In your app:
```javascript
const variantA = evaluate('variant-a', userId);
const variantB = evaluate('variant-b', userId);
if (variantA.on) { /* show variant A */ }
else if (variantB.on) { /* show variant B */ }
```

---

## 🧪 Testing & Verification

### Quick Smoke Test
```bash
npm run smoke
```

Creates a sample toggle and simulates traffic.

### Test with curl
```bash
# Create a toggle
curl -X POST http://localhost:3333/api/toggles \
  -H "x-admin-token: dev-secret" \
  -H "content-type: application/json" \
  -d '{"name":"test-feature","enabled":true,"rollout":50}'

# Evaluate for user
curl "http://localhost:3333/api/evaluate/test-feature?user=john&attrs={\"country\":\"US\"}"

# Get metrics
curl http://localhost:3333/api/metrics

# Rollback
curl -X POST http://localhost:3333/api/toggles/test-feature/rollback \
  -H "x-admin-token: dev-secret" \
  -H "content-type: application/json" \
  -d '{"reason":"Testing rollback"}'
```

---

## 📁 Files & Folder Structure

```
AIAC Project Toggle System/
├── server.js                  # Main Express app & API routes
├── toggleService.js           # Toggle CRUD operations
├── trafficRouter.js           # Feature evaluation logic
├── timeBucketMetrics.js       # Metrics aggregation (10s buckets)
├── rollbackController.js       # Automated rollback (background job)
├── audit.js                   # Audit log persistence
├── middleware.js              # Rate limiting & auth
├── public/index.html          # Beautiful dashboard UI
├── __tests__/all.test.js      # Jest unit tests
├── smoke-test.js              # Quick end-to-end test
├── toggle-store.json          # Persisted toggles (auto-created)
├── metrics-buckets.jsonl      # Metrics (auto-created)
├── audit-log.json             # Audit entries (auto-created)
├── package.json               # Dependencies
├── jest.config.js             # Jest configuration
├── README.md                  # Full documentation
└── GETTING_STARTED.md         # This file
```

---

## 🎯 Key Concepts

### Rollout Percentage
A value from 0-100 that controls what % of users see the feature.
- `0%`: Feature disabled for all users
- `50%`: Feature enabled for ~50% of users (determined by user ID hash)
- `100%`: Feature enabled for all users

### Deterministic Routing
The system uses SHA1 hashing of the user ID to decide rollout. **Same user always gets the same assignment**:
```
hash(user-123) → 42 → if 42 <= 50%, then ON; else OFF
```

### Constraints
Rules that filter who can see a feature:
```json
{
  "country": ["US", "CA"]  // Only US & Canada
}
```

Users from other countries will see feature OFF regardless of rollout %.

### Error Rate & Rollback
The system monitors error rates in **60-second sliding windows**:
```
error_rate = errors / exposures

If error_rate >= 25% AND exposures >= 8:
  → Automatically set rollout to 0% (rollback)
  → Log to audit
```

### Metrics
- **Exposures**: How many times the feature was evaluated
- **Activations**: How many users actually used the feature
- **Errors**: How many errors occurred while feature was enabled

---

## 🔧 Configuration & Customization

### Change Rollback Thresholds
Edit `server.js`:
```javascript
const rollback = new RollbackController(toggleService, metrics, {
  windowMs: 60 * 1000,          // 60-second window
  checkInterval: 5000,          // Check every 5 seconds
  errorRateThreshold: 0.25,     // 25% error rate threshold
  minExposures: 8               // Require 8+ exposures
});
```

### Change Server Port
```bash
PORT=8080 npm start
```

### Change Admin Token
```bash
ADMIN_TOKEN="super-secret-123" npm start
```

### Change Metrics Window
In dashboard, Metrics tab uses 60s by default. Edit `public/index.html`:
```javascript
const ms = 60 * 1000; // Change to 300 * 1000 for 5 minutes
const metrics = await apiGet('/api/metrics/window?ms=' + ms);
```

---

## 🚨 Troubleshooting

**Q: Dashboard won't load**
A: Make sure server is running: `npm start` and visit http://localhost:3333

**Q: API returns 403 (Forbidden)**
A: Admin token missing or wrong. Check header: `-H "x-admin-token: dev-secret"`

**Q: Rollback not triggered automatically**
A: 
- Need at least 8 exposures in 60s window
- Error rate must be ≥ 25%
- Wait 5+ seconds for rollback checker to run
- Check server logs: `tail -f server.log`

**Q: Metrics empty**
A: Generate traffic first! Use Test Evaluation tab to simulate requests.

**Q: Port 3333 already in use**
A: Kill old process: `pkill -f 'node server.js'` then `npm start`

---

## 🎓 Next Steps

### Integration with Your App
1. **Server-side**: Call `GET /api/evaluate/:feature?user=:userId&attrs=...` to check if feature is on
2. **Client-side**: Use SDK or call API from browser
3. **Mobile**: Same REST API works for iOS/Android

### Production Deployment
1. Set `ADMIN_TOKEN` environment variable
2. Use HTTPS (TLS/SSL)
3. Deploy behind a load balancer (multi-instance support coming)
4. Monitor error logs and metrics
5. Set up incident alerts (Slack webhook)

### Advanced Features
- Extend `trafficRouter.js` to add custom evaluation logic
- Extend `audit.js` to persist to a database
- Add webhooks for CI/CD integration
- Build custom analytics dashboard

---

## 📚 API Quick Reference

| Method | Endpoint | Auth | Purpose |
|--------|----------|------|---------|
| GET | `/api/toggles` | No | List all toggles |
| POST | `/api/toggles` | Yes | Create/update toggle |
| GET | `/api/toggles/:name` | No | Get specific toggle |
| POST | `/api/toggles/:name/rollback` | Yes | Manual rollback |
| GET | `/api/evaluate/:feature` | No | Check if feature ON for user |
| GET | `/api/metrics` | No | All-time stats |
| GET | `/api/metrics/window?ms=60000` | No | Windowed stats (60s default) |
| GET | `/api/metrics/prometheus` | No | Prometheus-format metrics |
| GET | `/api/audit` | No | Audit log entries |

---

## 💡 Pro Tips

1. **Monitor error rates closely** during rollout. If errors spike, use dashboard Rollback button immediately.
2. **Test with different user IDs** to verify both ON and OFF paths work.
3. **Use descriptive toggle names** (e.g., `new-checkout-ui`, `ai-recommendations-v2`).
4. **Audit logs are useful** for compliance and debugging—check them regularly.
5. **Plan your rollout**: Start small (5%), ramp gradually, watch metrics.

---

## 🎉 You're All Set!

You now have a **fully functional feature toggle system** ready to:
- ✅ Manage feature releases safely
- ✅ Monitor error rates in real-time
- ✅ Automatically rollback on errors
- ✅ Control who sees what features
- ✅ Track all changes via audit logs

**Start with the dashboard at http://localhost:3333 and enjoy safe feature releases!** 🚀
