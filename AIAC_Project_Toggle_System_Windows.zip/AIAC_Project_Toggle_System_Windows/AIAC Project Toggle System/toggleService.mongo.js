class ToggleServiceMongo {
  constructor(col) {
    this.col = col; // MongoDB collection
    this.toggles = {}; // in-memory cache by name
  }

  // factory to create and load cache
  static async create(db) {
    const col = db.collection('toggles');
    const svc = new ToggleServiceMongo(col);
    await svc._loadFromDb();
    return svc;
  }

  async _loadFromDb() {
    try {
      const all = await this.col.find({}).toArray();
      this.toggles = {};
      all.forEach(d => {
        // normalize dates to timestamps
        const copy = Object.assign({}, d);
        if (copy.createdAt && copy.createdAt.getTime) copy.createdAt = copy.createdAt.getTime();
        if (copy.updatedAt && copy.updatedAt.getTime) copy.updatedAt = copy.updatedAt.getTime();
        this.toggles[copy.name] = copy;
      });
      console.log('Loaded', Object.keys(this.toggles).length, 'toggles from MongoDB');
    } catch (e) {
      console.error('Failed to load toggles from DB', e.message);
    }
  }

  list() {
    return Object.values(this.toggles);
  }

  get(name) {
    return this.toggles[name];
  }

  async createOrUpdate(spec) {
    const now = Date.now();
    const existing = this.toggles[spec.name] || {};
    const updated = Object.assign({
      name: spec.name,
      enabled: spec.enabled === undefined ? true : spec.enabled,
      rollout: spec.rollout == null ? 0 : spec.rollout,
      constraints: spec.constraints || {},
      createdAt: existing.createdAt || now,
      updatedAt: now
    }, spec);

    // update in-memory cache immediately
    this.toggles[spec.name] = updated;

    // persist to DB and await result so callers can detect failures
    const toSave = Object.assign({}, updated);
    toSave.createdAt = new Date(toSave.createdAt);
    toSave.updatedAt = new Date(toSave.updatedAt);
    try {
      await this.col.updateOne({ name: toSave.name }, { $set: toSave }, { upsert: true });
      return updated;
    } catch (e) {
      // roll back in-memory cache to previous state if persistence failed
      if (existing && existing.name) this.toggles[spec.name] = existing;
      else delete this.toggles[spec.name];
      throw new Error('DB persist failed: ' + e.message);
    }
  }

  async setRollout(name, percent) {
    const t = this.toggles[name];
    if (!t) return null;
    t.rollout = Math.max(0, Math.min(100, percent));
    t.updatedAt = Date.now();

    try {
      await this.col.updateOne({ name }, { $set: { rollout: t.rollout, updatedAt: new Date(t.updatedAt) } });
      return t;
    } catch (e) {
      // revert change on failure
      // attempt to reload from DB
      try {
        const fresh = await this.col.findOne({ name });
        if (fresh) {
          if (fresh.createdAt && fresh.createdAt.getTime) fresh.createdAt = fresh.createdAt.getTime();
          if (fresh.updatedAt && fresh.updatedAt.getTime) fresh.updatedAt = fresh.updatedAt.getTime();
          this.toggles[name] = fresh;
        }
      } catch (e2) {}
      throw new Error('DB update failed: ' + e.message);
    }
  }
}

module.exports = ToggleServiceMongo;
