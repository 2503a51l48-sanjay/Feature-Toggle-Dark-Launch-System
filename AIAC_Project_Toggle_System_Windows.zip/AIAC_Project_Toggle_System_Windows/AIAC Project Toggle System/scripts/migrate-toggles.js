require('dotenv').config();
const path = require('path');
const fs = require('fs');
const Database = require('../db');

async function run() {
  const db = new Database(process.env.MONGODB_URI);
  const ok = await db.connect();
  if (!ok) {
    console.error('Database connection failed — aborting migration.');
    process.exit(2);
  }
  const togglesFile = path.join(__dirname, '..', 'toggle-store.json');
  if (!fs.existsSync(togglesFile)) {
    console.error('toggle-store.json not found at', togglesFile);
    await db.disconnect();
    process.exit(2);
  }

  const raw = fs.readFileSync(togglesFile, 'utf8');
  let items;
  try {
    items = JSON.parse(raw);
  } catch (err) {
    console.error('Failed to parse toggle-store.json:', err.message);
    await db.disconnect();
    process.exit(2);
  }

  const col = db.getDatabase().collection('toggles');
  let inserted = 0;
  let skipped = 0;
  let updated = 0;

  for (const [key, t] of Object.entries(items)) {
    const name = t.name || key;
    // Check existing
    const existing = await col.findOne({ name });
    if (existing) {
      // Skip duplicates (do not overwrite)
      skipped++;
      continue;
    }
    const now = new Date();
    const doc = Object.assign({}, t, {
      name,
      enabled: typeof t.enabled === 'boolean' ? t.enabled : true,
      rollout: typeof t.rollout === 'number' ? t.rollout : 0,
      constraints: t.constraints || {},
      createdAt: t.createdAt ? new Date(t.createdAt) : now,
      updatedAt: t.updatedAt ? new Date(t.updatedAt) : now
    });
    await col.insertOne(doc);
    inserted++;
  }

  console.log(JSON.stringify({ inserted, skipped, updated }, null, 2));
  await db.disconnect();
  process.exit(0);
}

run().catch(async (err) => {
  console.error('Migration failed:', err);
  try { const db = new Database(process.env.MONGODB_URI); await db.disconnect(); } catch(e){}
  process.exit(1);
});
