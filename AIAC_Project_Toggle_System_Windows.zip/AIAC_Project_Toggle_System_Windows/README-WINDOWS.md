# Windows Setup — AIAC Project Toggle System

## Prerequisites
- Windows 10/11
- Node.js (LTS recommended). Download from https://nodejs.org and install (make sure `node` and `npm` are available in PATH).
- Git (optional, for cloning the repo)

## Quick start (recommended)
1. Open Command Prompt or PowerShell in the project folder (where package.json is).
2. Run the helper script for an automated setup:
   - Command Prompt: `start-windows.bat`
   - PowerShell: `.un-windows.ps1`
3. The script will run `npm install` and then `npm start`.

## Manual steps
1. Open PowerShell or Command Prompt in the project directory.
2. Install dependencies: `npm install`
3. Start the app: `npm start` or `npm run dev` (if available)

## Common Windows-specific tips
- If `npm install` fails with permission errors, try running the terminal as administrator or use `--no-optional` to skip optional modules.
- If you see native build failures, install windows-build-tools (only if required):
  ```powershell
  npm i -g windows-build-tools
  ```
- For long-running server on Windows, consider using `pm2` (cross-platform process manager):
  ```powershell
  npm i -g pm2
  pm2 start npm --name "aiac-toggle" -- start
  ```

## Where to find help
- Check `README.md` included in the repository for project-specific notes.
- Open an issue in the project tracker or contact the maintainer.