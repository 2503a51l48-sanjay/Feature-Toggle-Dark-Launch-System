# PowerShell script to run the AIAC Project Toggle System on Windows
# Run this script from PowerShell (preferably as CurrentUser, not restricted)
# If execution is restricted, run: Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned
Write-Output "Installing dependencies (this may take a few minutes)..."
npm install
if ($LASTEXITCODE -ne 0) {
    Write-Error "npm install failed. Make sure Node.js and npm are installed and in PATH."
    exit $LASTEXITCODE
}
Write-Output "Starting the application..."
npm start